import os
import sys
print(sys.version)
sys.path = ['/home/dndtools/dndtools2/dndtools' , '/home/dndtools/dndtools2/dndtools/dndtools'] + sys.path
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "dndtools.settings")
import django.core.handlers.wsgi
application = django.core.handlers.wsgi.WSGIHandler()