# -*- coding: utf-8 -*-

import os



DIRNAME = os.path.dirname(os.path.abspath(__file__))

# Change this to False if you run it in development
DEBUG = False
TEMPLATE_DEBUG = DEBUG

# See https://docs.djangoproject.com/en/1.6/ref/settings/#databases for reference
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'dndarkal_tools',
        'USER': 'dndarkal_tools',
        'PASSWORD': 'Al199127owned',
        'HOST': '',
        'PORT': ''
        }
}


# Make this unique, and don't share it with anybody.
SECRET_KEY = 'asdfkjnawipo#$%!@#'

MEDIA_ROOT = os.path.join(DIRNAME, 'static/')

SITE_ID = 1

INTERNAL_IPS = ('127.0.0.1', )

TEMPLATE_DIRS = (
    os.path.join(DIRNAME, 'templates/'),
)
RECAPTCHA_PUBLIC = '6Lc_fx0dAAAAALBbPrKE_CIG8tZvAuWJaId36O3t'
RECAPTCHA_PRIVATE = '6Lc_fx0dAAAAAG9qZS2nGu8iCf4PX8rTaBh-fqtd'
